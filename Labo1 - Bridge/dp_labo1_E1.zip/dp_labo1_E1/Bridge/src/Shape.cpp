#include "Shape.h"

Shape::Shape(Drawing* _apiDrawing) : apiDrawing(_apiDrawing)
{

}

Shape::~Shape()
{
    //dtor
}
