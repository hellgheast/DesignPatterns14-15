#include "Drawing.h"

Drawing::Drawing()
{
    //ctor
}



Drawing::~Drawing()
{
    //dtor
}
